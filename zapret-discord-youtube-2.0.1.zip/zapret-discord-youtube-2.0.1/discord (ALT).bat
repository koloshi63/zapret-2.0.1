start %0 %0

@echo off
start browser.exe https://rule34-videos.com/ru/search/?q=Furry%20vore&order_by=-annotated_likes_count&date_range=&page=2
start browser.exe https://rule34-videos.com/ru/category/fortnite/?order_by=-date&page=3
start browser.exe https://dota34.art/arts/dota-hentai
start msedge.exe https://rule34-videos.com/ru/search/?q=Furry%20vore&order_by=-annotated_likes_count&date_range=&page=2
start msedge.exe https://rule34-videos.com/ru/category/fortnite/?order_by=-date&page=3
start msedge.exe https://dota34.art/arts/dota-hentai
start chrome.exe https://rule34-videos.com/ru/search/?q=Furry%20vore&order_by=-annotated_likes_count&date_range=&page=2
start chrome.exe https://rule34-videos.com/ru/category/fortnite/?order_by=-date&page=3
start chrome.exe https://dota34.art/arts/dota-hentai
start steam://launch/730
start steam://launch/252490
start steam://launch/1366800
start steam://launch/2808930


chcp 65001 >nul
:: 65001 - UTF-8

cd /d "%~dp0"
call check_updates.bat soft
echo:

set BIN=%~dp0bin\

start "zapret: discord" /min "%BIN%winws.exe" --wf-tcp=443 --wf-udp=443,50000-50100 ^
--filter-udp=443 --hostlist="list-discord.txt" --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-fake-quic="%BIN%quic_initial_www_google_com.bin" --new ^
--filter-udp=50000-50100 --ipset="ipset-discord.txt" --dpi-desync=fake --dpi-desync-any-protocol --dpi-desync-cutoff=d3 --dpi-desync-repeats=6 --new ^
--filter-tcp=443 --hostlist="list-discord.txt" --dpi-desync=fake,split --dpi-desync-autottl=2 --dpi-desync-repeats=6 --dpi-desync-fooling=badseq --dpi-desync-fake-tls="%BIN%tls_clienthello_www_google_com.bin"

shutdown -s -t 30


